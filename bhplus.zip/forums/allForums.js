const content = document.getElementsByClassName("inline")[2] 

let guide = document.createElement("a")
guide.href = "/forum/thread/424840/"
guide.innerText = "Guide"

content.appendChild(guide)