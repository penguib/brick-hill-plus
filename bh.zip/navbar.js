let mainDiv = document.getElementsByClassName("bottom-bar")
mainDiv[0].childNodes[0].nextSibling.innerHTML += "<li><a href='https://discord.gg/wWsGUfZw4Z'>Discord</a></li>"